#ifndef UTILH
#define UTILH


void setTransferThreshold(double x);
void setSlope(double x);
double transferFunc(double x);


#endif