#ifndef UTILH
#define UTILH


void setTransferThreshold(double x);
double transferFunc(double x);


#endif